package com.example.practicaintent_;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
private ImageButton perro;
private ImageButton gato;
private ImageButton loro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        perro = findViewById(R.id.perro);
        gato = findViewById(R.id.gato);
        loro = findViewById(R.id.loro);
    }
    public void irperro(View view){
        Intent intent1=new Intent(this, MainActivity2.class);
        startActivity(intent1);

    }
    public void irgato(View view){
        Intent intent2=new Intent(this, MainActivity3.class);
        startActivity(intent2);

    }
    public void irloro(View view){
        Intent intent3=new Intent(this, MainActivity4.class);
        startActivity(intent3);

    }
}